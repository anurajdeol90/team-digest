# Weekly Team Digest

## Alpha Update
Alpha budget approved.
